BB Block Dice by Hampy on Thingiverse: https://www.thingiverse.com/thing:3040047

Summary:
Dice for Blood Bowl