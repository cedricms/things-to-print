Root compatible D8 dice by GRUXXKi on Thingiverse: https://www.thingiverse.com/thing:3904285

Summary:
This a compatible D8 dice with faces having : 0, 1, 2 and 3.