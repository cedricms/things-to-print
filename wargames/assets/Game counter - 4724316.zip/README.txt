Game counter by Sterister on Thingiverse: https://www.thingiverse.com/thing:4724316

Summary:
Inside the wheel there's a compliant mechanism for each wheel. So if you were to rotate, the wheel would spin and snap in position for the next number.Maybe you could use the left for HP, and the other one for initiative or gold etc. Every number/spacer is one module, except the end caps.There are various rods you can print, meant to hold different amounts of modules, so you can customize to your heart's content. 