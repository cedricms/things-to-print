Every number/spacer is one module, except the end caps. 
There's various rods you can print, meant to hold different amounts of modules, so you can customize to your heart's content. 
You are NOT permitted to sell the files, or any of the printed parts. 

Take care!
-Sterister